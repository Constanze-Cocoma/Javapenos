package org.academiadecodigo.bootcamp.javapenos_game;

import org.academiadecodigo.simplegraphics.pictures.Picture;

public class PlayGrid{ //implements Grid {

    public static final int PADDING = 10;
    public static final int FX_PADDING = 100;
    public static final int MAX_JAVAS = 10;


    private static int width; // mudar para static final quando soubermos as medidas
    private static int height;


    public PlayGrid(int PADDING, int width, int height) {
        /*Rectangle canvas = new Rectangle(PADDING, PADDING, width, height);
        canvas.draw();*/
    }

    public void playInit() {
        Picture backImage = new Picture(FX_PADDING, FX_PADDING, "fundo_576x768.png");

        backImage.draw();
        //middleImage.draw();
        //frontImage.draw();

    }

    public static int getWidth() {
        return width;
    }

    public static int getHeight() {
        return height;
    }

}
