package org.academiadecodigo.bootcamp.javapenos_game;

public class Main {
    public static void main(String[] args) {

        PlayGrid playGrid = new PlayGrid(PlayGrid.PADDING, 715, 876);
        playGrid.playInit();

        Player player = new Player();
        player.playStart();
    }
}
