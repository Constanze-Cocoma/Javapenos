package org.academiadecodigo.bootcamp.javapenos_game;

import org.academiadecodigo.simplegraphics.graphics.Rectangle;
import org.academiadecodigo.simplegraphics.pictures.Picture;

public class StartGrid implements Grid {

    private int width;
    private int height;
    public static final int PADDING = 10;
    public static final int FX_PADDING = 100;

    private Rectangle canva;
    private Picture backImage;
    private Picture middleImage;
    private Picture frontImage;

    /**
     * Simple graphics grid constructor with a certain number of pixel width and height
     *
     * @param width  width in pixels
     * @param height height in pixels
     */
    public StartGrid(int width, int height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Initializes the grid
     */
    @Override
    public void init() {
        this.canva = new Rectangle(PADDING, PADDING, getWidth(), getHeight());
        this.canva.draw();
    }

    /**
     * Create a random grid position
     *
     * @return the new grid position
     */
    //public GridPosition makeGridPosition();

    public void startInit() {
        Picture title = new Picture(180, 200, "title.png");
        Picture backImage = new Picture(FX_PADDING, FX_PADDING, "pedra-deslizante_576x768.png");
        Picture middleImage = new Picture(FX_PADDING, FX_PADDING, "muro_576x768.png");
        Picture frontImage = new Picture(PADDING, PADDING, "enfeites.png");
        backImage.draw();
        middleImage.draw();
        frontImage.draw();
        title.draw();
    }

    /**
     * Creates a a grid position in a specific column and row
     *
     *
     * @return the new grid position
     */
    //public GridPosition makeGridPosition(int col, int row);
/*
    public Position makeGridPosition(int x, int y) {
        return //retornar uma grip position com (x, y, this grid)
    }
*/
    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

}
