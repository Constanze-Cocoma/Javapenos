package org.academiadecodigo.bootcamp.javapenos_game;

/**
 * The available types of grids
 */
public enum GridType {
    START,
    PLAY,
    END
}

