package org.academiadecodigo.bootcamp.javapenos_game;

import org.academiadecodigo.simplegraphics.keyboard.Keyboard;
import org.academiadecodigo.simplegraphics.keyboard.KeyboardEvent;
import org.academiadecodigo.simplegraphics.keyboard.KeyboardEventType;
import org.academiadecodigo.simplegraphics.keyboard.KeyboardHandler;
import org.academiadecodigo.simplegraphics.pictures.Picture;

import static org.academiadecodigo.bootcamp.javapenos_game.PlayGrid.*;


// temos ainda que corrigir o facto de a imagem ultrapassar os limites do grid


public class Player implements KeyboardHandler {

    private PlayGrid playGrid;
    private StartGrid startGrid;

    private Picture pic = new Picture(345, 620, "boneco2_130x188.png");
    private Picture frontImage = new Picture(PADDING, PADDING, "enfeites.png");
    private Picture middleImage = new Picture(FX_PADDING, FX_PADDING, "muro_576x768.png");
    private Picture backImage = new Picture(FX_PADDING, FX_PADDING, "fundo_576x768.png");
    private Picture muroImage = new Picture(FX_PADDING, FX_PADDING, "pedra-deslizante_576x768.png");
    private Picture title = new Picture(180, 200, "title.png");
    private Picture instruction = new Picture(220,330,"instructions.png");
    private Picture how_to = new Picture(260,395,"how_to.png");
    private Picture redExp = new Picture(380,730,"redExp.png");
    private Picture greenExp = new Picture(180,680,"greenExp.png");

    private Keyboard kb = new Keyboard(this);

    public void playStart() {
        draw();
        activateKeys();
    }

    public void draw() {
        muroImage.draw();
        title.draw();
        instruction.draw();
        how_to.draw();
        redExp.draw();
        greenExp.draw();
        middleImage.draw();
        frontImage.draw();
    }

    public void activateKeys() {
        addEventToKeyboard(KeyboardEvent.KEY_SPACE, KeyboardEventType.KEY_PRESSED);
        addEventToKeyboard(KeyboardEvent.KEY_Q, KeyboardEventType.KEY_PRESSED);
        addEventToKeyboard(KeyboardEvent.KEY_UP, KeyboardEventType.KEY_PRESSED);
        addEventToKeyboard(KeyboardEvent.KEY_LEFT, KeyboardEventType.KEY_PRESSED);
        addEventToKeyboard(KeyboardEvent.KEY_RIGHT, KeyboardEventType.KEY_PRESSED);
        addEventToKeyboard(KeyboardEvent.KEY_R, KeyboardEventType.KEY_PRESSED);
    }

    private void addEventToKeyboard(int keySpace, KeyboardEventType keyPressed) {
        KeyboardEvent event = new KeyboardEvent();
        event.setKey(keySpace);
        event.setKeyboardEventType(keyPressed);
        kb.addEventListener(event);
    }

    @Override
    public void keyPressed(KeyboardEvent keyboardEvent) {
        switch (keyboardEvent.getKey()) {
            case KeyboardEvent.KEY_SPACE:
                // add behaviour for space key later on (start game for example)
                int count = 1;
                int meh = 0;
                if (meh < count) {
                    middleImage.delete();
                    title.delete();
                    instruction.delete();
                    how_to.delete();
                    redExp.delete();
                    greenExp.delete();
                    muroImage.delete();
                    frontImage.delete();
                    backImage.draw();
                    pic.draw();
                    middleImage.draw();
                    frontImage.draw();

                    meh++;
                    break;
                }
                break;

            case KeyboardEvent.KEY_R:
                // return to menu
                pic.delete();
                backImage.delete();
                middleImage.delete();
                frontImage.delete();
                muroImage.draw();
                title.draw();
                instruction.draw();
                how_to.draw();
                redExp.draw();
                greenExp.draw();
                middleImage.draw();
                frontImage.draw();
                break;

            case KeyboardEvent.KEY_Q:
                // exit game
                int num = 1;
                System.exit(num);
                break;

            case KeyboardEvent.KEY_RIGHT:
                if (pic.getX() < 520) {
                    pic.translate(30, 0);
                    break;
                }
                break;

            case KeyboardEvent.KEY_LEFT:
                if (pic.getX() > getWidth() + PADDING + FX_PADDING + 40) {
                    pic.translate(-30, 0);
                    break;
                }
                break;
        }
    }

    @Override
    public void keyReleased(KeyboardEvent keyboardEvent) {
    }
}
