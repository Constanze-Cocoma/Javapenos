package org.academiadecodigo.bootcamp.javapenos_game;

public class EndGrid{ //implements Grid {
}
